# Prompt pronto da copiare — GG Studio Giorgi su Google Sites

> Allega a questo prompt il **PNG originale del logo** e le **fotografie originali dello Studio** mostrate nella richiesta. Non sostituirli con immagini reperite online.

---

Agisci come un web designer e content designer esperto di **Google Sites (nuova versione)**. Prepara un sito professionale, pulito, moderno e accattivante, in italiano, per **GG Studio Giorgi — Studio di Dottori Commercialisti, Professionisti per l’impresa**, da pubblicare su **ggstudio.tax**.

**Vincolo decisivo:** il risultato deve essere **realizzabile in Google Sites**. Non consegnare un progetto React, Next.js, WordPress o una pagina HTML completa da “importare”: Google Sites si costruisce con le sue sezioni e permette di incorporare servizi e widget, ma non di caricare un’applicazione come sito completo. Fornisci testi pronti da incollare, indicazioni precise blocco per blocco e, solo dove serve davvero, un widget incorporabile. Usa i layout responsive, i pulsanti, le immagini, le pagine, i Moduli e le Mappe nativi di Google Sites.

## Identità visiva e materiali

- Usa il **PNG allegato come logo**, senza ridisegnarlo, ricolorarlo, ritagliarlo, deformarlo o sostituirlo con una reinterpretazione. Mantieni integre scritte, proporzioni e spaziature. Se Google Sites lo mostra troppo piccolo nell’intestazione, inserisci anche il file originale come immagine nella prima sezione, conservando le proporzioni.
- Usa **solo le fotografie allegate** per rappresentare gli interni dello Studio: corridoio con quadro, sala riunioni, passaggi e opere d’arte, ufficio, postazioni di lavoro e insegna esterna. Evita foto stock o generate. Le eventuali immagini duplicate vanno usate una volta sola. La foto con decorazioni natalizie può stare nella galleria, non come immagine principale permanente.
- Imposta un design luminoso con bianco e grigi chiari, blu profondo coordinato al logo, tipografia leggibile, ampi spazi, titoli incisivi e un tono autorevole ma umano. Verifica leggibilità e impaginazione nell’anteprima mobile di Google Sites.
- Scrivi testi credibili e originali. **Non inventare** nomi di professionisti, Partita IVA, premi, anni di attività, recensioni, risultati, aliquote, scadenze fiscali o notizie non fornite.

## Dati da riportare fedelmente

- Denominazione: **GG Studio Giorgi**.
- Attività: **Studio di Dottori Commercialisti — Professionisti per l’impresa**. Per la scritta nel logo prevale sempre il testo effettivo presente nel PNG.
- Indirizzo: **Via Giuseppe Verdi n. 18, 59100 Prato (PO)**.
- Telefono: **0574 572757**, cliccabile con `tel:+390574572757`.
- Email: **info@ggstudio.tax**, cliccabile con `mailto:info@ggstudio.tax`.
- Dominio: **ggstudio.tax**.
- Orari: **Lunedì 09:00–13:00 e 15:00–19:00; Martedì 09:00–13:00; Mercoledì 09:00–13:00 e 15:00–19:00; Giovedì 09:00–13:00; Venerdì 09:00–13:00 e 15:00–19:00. Sabato e domenica chiuso.**
- Social ufficiali, con icone o pulsanti cliccabili, visibili almeno nel footer e nella pagina Contatti:
  - Facebook: https://www.facebook.com/studiogiorgi.giorgi/
  - Instagram: https://www.instagram.com/ggstudiogiorgi/
  - YouTube: https://www.youtube.com/@ggstudiogiorgi
  - TikTok: https://www.tiktok.com/@ggstudiogiorgi

## Struttura da costruire in Google Sites

1. **Home**: hero con logo e foto orizzontale della sala riunioni, titolo di valore, breve presentazione dello Studio, pulsanti “Scopri lo studio” e “Contattaci”; panoramica delle competenze; anteprima degli spazi con foto reali; ultime tre news aggiornabili; invito finale a scrivere o telefonare.
2. **Lo Studio**: presentazione dello Studio e del metodo di lavoro senza biografie inventate; galleria ordinata e adattabile al mobile con le foto allegate e didascalie sobrie.
3. **Competenze**: descrizioni brevi e comprensibili di consulenza fiscale e tributaria, contabile, societaria, aziendale e finanziaria, operazioni straordinarie e tutela del patrimonio. Non promettere prestazioni non confermate.
4. **News e approfondimenti**: archivio aggiornabile nel tempo. Per ottenere un vero aggiornamento senza ricostruire le pagine di Google Sites, usa **un Foglio Google privato come archivio editoriale** e un **widget di sola lettura di Google Apps Script** incorporato con “Inserisci → Incorpora”. Prevedi colonne Data, Categoria, Titolo, Sommario, Testo e Stato (BOZZA/PUBBLICATO); mostra solo le righe PUBBLICATO, ordinate per data, le tre più recenti in Home e l’archivio completo nella pagina News. Se non ci sono articoli, mostra un messaggio onesto e curato. Non chiamare “dinamica” una lista che richiede di modificare manualmente il layout di Google Sites.
5. **Contatti**: recapiti cliccabili, orari completi, pulsante “Indicazioni stradali”, **mappa Google Maps** inserita con il blocco Mappe di Google Sites e centrata su Via Giuseppe Verdi n. 18, Prato. Inserisci un **Google Modulo** nella stessa pagina usando il blocco Moduli nativo, con Nome e cognome, Email, Telefono facoltativo, Argomento, Messaggio e accettazione obbligatoria dell’informativa privacy. Il modulo deve registrare le risposte e mostrare una conferma; spiega come attivare le notifiche email delle nuove risposte al proprietario del modulo e, se il proprietario non usa `info@ggstudio.tax`, come inviare notifiche a quell'indirizzo con un trigger Apps Script installabile. Non disegnare un form fittizio che non invia nulla.
6. **Privacy**: pagina collegata al modulo e al footer. Fornisci una bozza informativa chiaramente indicata come da verificare prima della pubblicazione; non inventare dati societari o informazioni legali mancanti.

## Requisiti di consegna

Fornisci in ordine: **(a)** albero delle pagine; **(b)** palette e impostazioni tema Google Sites; **(c)** layout sezione per sezione specificando quale blocco nativo usare e quale foto allegata posizionare; **(d)** tutti i titoli e testi pronti da incollare; **(e)** istruzioni semplici per creare e incorporare Google Moduli, Google Maps e il widget news Google Sheets + Apps Script; **(f)** schema del Foglio News e procedura per aggiungere una notizia; **(g)** checklist finale per mobile, link, accessibilità, privacy, dominio personalizzato ggstudio.tax e pubblicazione. Evita segnaposto generici nei testi pubblici; usa segnaposto soltanto per identificativi e URL che devono necessariamente essere creati nell’account Google.

---

**Nota pratica:** la versione Next.js eventualmente usata come anteprima non è importabile direttamente in Google Sites. Il risultato richiesto qui è un progetto editoriale e un piano di montaggio Google Sites, non un archivio ZIP da caricare.
