/**
 * GG Studio Giorgi — News per Google Sites.
 * Il Foglio Google ha una scheda "News" con sei colonne:
 * Data | Categoria | Titolo | Sommario | Testo | Stato
 *
 * Sostituisci soltanto l'ID qui sotto con quello del tuo Foglio.
 * Il Foglio resta privato; il web app mostra solo le righe PUBBLICATO.
 */
var NEWS_SHEET_ID = 'INCOLLA_ID_DEL_FOGLIO';
var NEWS_SHEET_NAME = 'News';

function doGet(e) {
  var view = e && e.parameter && e.parameter.view === 'all' ? 'all' : 'latest';
  var template = HtmlService.createTemplateFromFile('Index');
  template.view = view;
  template.news = [];
  template.error = '';

  try {
    template.news = readPublishedNews_(view);
  } catch (error) {
    console.error('Impossibile leggere le news: ' + error);
    template.error = 'Le news non sono temporaneamente disponibili.';
  }

  // Il contenuto è solo in lettura: non ci sono pulsanti amministrativi nel frame.
  return template.evaluate()
    .setTitle('News — GG Studio Giorgi')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function readPublishedNews_(view) {
  if (!NEWS_SHEET_ID || NEWS_SHEET_ID === 'INCOLLA_ID_DEL_FOGLIO') {
    throw new Error('Inserisci l\'ID del Foglio Google in NEWS_SHEET_ID.');
  }

  var sheet = SpreadsheetApp.openById(NEWS_SHEET_ID).getSheetByName(NEWS_SHEET_NAME);
  if (!sheet) throw new Error('Scheda News non trovata.');
  var lastRow = sheet.getLastRow();
  if (lastRow < 2) return [];

  var rows = sheet.getRange(2, 1, lastRow - 1, 6).getValues();
  var published = [];

  rows.forEach(function (row) {
    var state = String(row[5] || '').trim().toUpperCase();
    var title = String(row[2] || '').trim();
    var date = row[0];
    if (state !== 'PUBBLICATO' || !title || !(date instanceof Date) || isNaN(date.getTime())) return;

    published.push({
      timestamp: date.getTime(),
      iso: Utilities.formatDate(date, 'Europe/Rome', 'yyyy-MM-dd'),
      date: Utilities.formatDate(date, 'Europe/Rome', 'dd/MM/yyyy'),
      category: String(row[1] || 'News').trim() || 'News',
      title: title,
      excerpt: String(row[3] || '').trim(),
      body: String(row[4] || '').trim()
    });
  });

  published.sort(function (a, b) { return b.timestamp - a.timestamp; });
  return published.slice(0, view === 'all' ? 100 : 3);
}
