/**
 * NOTIFICHE OPZIONALI PER IL MODULO GOOGLE "Contatta GG Studio Giorgi".
 * Incolla questo file nell'editor Apps Script aperto DAL MODULO GOOGLE.
 * Esegui installContactTrigger() una sola volta e autorizza lo script.
 * Non pubblicare come web app: viene eseguito solo dal trigger del modulo.
 */
var STUDIO_CONTACT_EMAIL = 'info@ggstudio.tax';

function installContactTrigger() {
  var form = FormApp.getActiveForm();
  if (!form) throw new Error('Apri Apps Script dal Modulo Google, non da un progetto indipendente.');

  var installed = ScriptApp.getProjectTriggers().some(function (trigger) {
    return trigger.getHandlerFunction() === 'notifyStudio';
  });
  if (installed) {
    Logger.log('Il trigger notifyStudio è già installato.');
    return;
  }

  ScriptApp.newTrigger('notifyStudio').forForm(form).onFormSubmit().create();
  Logger.log('Trigger installato: i nuovi messaggi saranno notificati a ' + STUDIO_CONTACT_EMAIL);
}

function notifyStudio(e) {
  if (!e || !e.response) throw new Error('Questa funzione deve essere chiamata dal trigger del Modulo.');
  var senderEmail = '';
  var lines = e.response.getItemResponses().map(function (itemResponse) {
    var question = itemResponse.getItem().getTitle();
    var value = itemResponse.getResponse();
    var answer = Array.isArray(value) ? value.join(', ') : String(value == null ? '' : value);
    if (question === 'Indirizzo email') senderEmail = answer.trim();
    return question + ': ' + answer;
  });

  var message = {
    to: STUDIO_CONTACT_EMAIL,
    subject: 'Nuova richiesta dal sito GG Studio Giorgi',
    body: 'Hai ricevuto una nuova richiesta dal Modulo Google del sito.\n\n' + lines.join('\n\n') + '\n\nLe risposte complete sono conservate nel Modulo Google.',
    name: 'GG Studio Giorgi — sito'
  };

  if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(senderEmail)) message.replyTo = senderEmail;
  MailApp.sendEmail(message);
}
