# Testi pronti da incollare in Google Sites

Questi testi sono proposte editoriali basate soltanto sulle informazioni disponibili. Usali nei blocchi di testo nativi di Google Sites; sostituisci solo ciò che lo Studio desidera specificare meglio. Non aggiungere referenze, anni di esperienza, nomi di professionisti, Partita IVA o notizie non verificate.

## HOME

**Sovratitolo:** STUDIO DI DOTTORI COMMERCIALISTI · PRATO

**Titolo principale:** La tua impresa, una nuova prospettiva.

**Introduzione:** In GG Studio Giorgi affianchiamo imprese e professionisti con una consulenza attenta alle persone, ai numeri e alle decisioni che contano. Uno Studio di Dottori Commercialisti a Prato, vicino ai tuoi progetti.

**Pulsanti:** Scopri lo Studio → pagina Lo Studio · Parliamone → pagina Contatti

### Oltre i numeri, ci sono le persone

Ogni realtà ha esigenze, obiettivi e sfide diverse. Per questo partiamo dall'ascolto, lavoriamo con chiarezza e cerchiamo soluzioni capaci di guardare oltre l'oggi. La consulenza è prima di tutto una relazione di fiducia.

### Competenze diverse. Una sola direzione.

- **Consulenza fiscale e tributaria:** supporto per affrontare adempimenti e scelte con maggiore consapevolezza.
- **Consulenza contabile:** dati chiari e strumenti utili per leggere l'andamento della tua attività.
- **Consulenza societaria:** un affiancamento nelle decisioni che riguardano la struttura e l'evoluzione dell'impresa.
- **Consulenza aziendale e finanziaria:** una visione d'insieme per orientare progetti e obiettivi.
- **Operazioni straordinarie:** metodo e attenzione nei momenti di cambiamento.
- **Tutela del patrimonio:** uno sguardo responsabile a ciò che hai costruito e al suo futuro.

**Pulsante:** Scopri le competenze → pagina Competenze

### Un luogo dove incontrarsi

I nostri spazi, nel cuore di Prato, raccontano un modo di lavorare fatto di ascolto, dialogo e attenzione ai dettagli. Entra nel nostro Studio attraverso le fotografie degli ambienti reali.

**Pulsante:** Entra nello Studio → pagina Lo Studio

### News e approfondimenti

Uno spazio per condividere notizie, spunti e punti di vista utili a imprese e professionisti. Le pubblicazioni sono aggiornate dallo Studio.

**Testo quando non ci sono news pubblicate:** Stiamo preparando i prossimi approfondimenti. Torna a trovarci presto.

**Pulsante:** Tutte le news → pagina News

### Iniziamo da una conversazione

Hai una domanda o un progetto? Raccontaci di cosa hai bisogno: saremo felici di ascoltarti.

**Pulsante:** Contatta lo Studio → pagina Contatti

## LO STUDIO

**Titolo principale:** Prima di tutto, le persone.

**Introduzione:** GG Studio Giorgi è uno Studio di Dottori Commercialisti a Prato. Crediamo in un rapporto di fiducia che nasce dall'ascolto e cresce nel tempo: conoscere la tua realtà ci aiuta a guardare le questioni da più prospettive.

### Un modo di lavorare vicino a te

Affrontare una decisione fiscale, contabile o societaria può essere complesso. Il nostro obiettivo è rendere più chiaro il percorso, mettere a fuoco le priorità e accompagnarti con attenzione nelle scelte per la tua attività.

### Dentro lo Studio

Ci piace pensare allo Studio come a uno spazio di confronto. Le immagini che trovi qui mostrano gli ambienti reali in cui incontriamo clienti, condividiamo idee e lavoriamo ogni giorno.

**Didascalie galleria:** La sala riunioni · Gli spazi dello Studio · Arte e dettagli · I nostri uffici · Le postazioni di lavoro · L'ingresso di GG Studio Giorgi.

**Pulsante:** Vieni a trovarci → pagina Contatti

## COMPETENZE

**Titolo principale:** Competenze che dialogano. Soluzioni che guardano avanti.

**Introduzione:** Ogni scelta professionale merita attenzione e una visione completa. Ecco le aree in cui GG Studio Giorgi può affiancare imprese e professionisti.

1. **Consulenza fiscale e tributaria** — Un supporto per interpretare gli adempimenti e orientare le scelte fiscali con chiarezza, tenendo conto della situazione di ogni cliente.
2. **Consulenza contabile** — I numeri raccontano la tua attività. Ti aiutiamo a organizzarli e leggerli come strumenti per decidere con maggiore consapevolezza.
3. **Consulenza societaria** — Dalla struttura alle fasi di evoluzione dell'impresa, lavoriamo insieme per mettere a fuoco le decisioni societarie.
4. **Consulenza aziendale e finanziaria** — Analizziamo esigenze e prospettive per accompagnare la pianificazione e le scelte dell'attività.
5. **Operazioni straordinarie** — Nei passaggi di cambiamento serve una visione d'insieme: offriamo supporto nell'analisi e nella gestione dei percorsi straordinari.
6. **Tutela del patrimonio** — Ogni progetto merita continuità. Affrontiamo insieme le questioni legate alla protezione del patrimonio e al futuro dell'attività.

**Chiusura:** Nessuna realtà è uguale a un'altra. Il primo passo è parlarne.

**Pulsante:** Richiedi un contatto → pagina Contatti

## NEWS

**Titolo principale:** Idee, novità e punti di vista.

**Introduzione:** Uno spazio aggiornato da GG Studio Giorgi per condividere approfondimenti e informazioni utili alle imprese e ai professionisti.

**Stato vuoto:** Le prossime news arriveranno qui. Seguici anche sui nostri canali social per rimanere in contatto.

_Inserire sotto questo testo il web app News descritto in `GUIDA.md`; non creare notizie fittizie per riempire la pagina._

## CONTATTI

**Titolo principale:** Iniziamo da una conversazione.

**Introduzione:** Hai una domanda, un progetto o semplicemente vuoi conoscerci? Puoi scriverci, chiamarci o venire a trovarci nel cuore di Prato.

**Indirizzo:** Via Giuseppe Verdi n. 18, 59100 Prato (PO)

**Telefono:** 0574 572757

**Email:** info@ggstudio.tax

**Orari di apertura:**

| Giorno | Orario |
| --- | --- |
| Lunedì | 09:00–13:00 · 15:00–19:00 |
| Martedì | 09:00–13:00 |
| Mercoledì | 09:00–13:00 · 15:00–19:00 |
| Giovedì | 09:00–13:00 |
| Venerdì | 09:00–13:00 · 15:00–19:00 |
| Sabato e domenica | Chiuso |

**Sopra il Modulo Google:** Raccontaci di cosa hai bisogno. Compila il modulo e ti risponderemo appena possibile.

**Sopra la mappa:** Ci trovi a Prato, in Via Giuseppe Verdi 18. Apri la mappa per raggiungerci.

**Pulsante mappa:** Indicazioni stradali → https://www.google.com/maps/search/?api=1&query=Via+Giuseppe+Verdi+18%2C+59100+Prato

**Social:** Facebook · Instagram · YouTube · TikTok, collegati agli URL ufficiali in `GUIDA.md`.

## FOOTER COMUNE

**Testo:** GG Studio Giorgi — Professionisti per l'impresa. Via Giuseppe Verdi n. 18, 59100 Prato (PO) · 0574 572757 · info@ggstudio.tax

**Link:** Home · Lo Studio · Competenze · News · Contatti · Privacy · Facebook · Instagram · YouTube · TikTok.

## PRIVACY — DA VERIFICARE PRIMA DELLA PUBBLICAZIONE

La pagina Privacy e il testo del consenso devono essere approvati dallo Studio o da un consulente privacy. I seguenti sono **punti da completare**, non un'informativa legale definitiva:

1. Titolare del trattamento e recapiti corretti dell'ente che gestisce GG Studio Giorgi.
2. Dati raccolti dal Modulo Google (nome, email, telefono se inserito, argomento e messaggio), finalità di risposta alla richiesta e base giuridica appropriata.
3. Conservazione dei dati, soggetti autorizzati, fornitori coinvolti (inclusi Google Forms/Sheets e l'eventuale widget), possibili trasferimenti e misure adottate.
4. Diritti dell'interessato e modalità per esercitarli scrivendo a **info@ggstudio.tax**.
5. Eventuali altri strumenti di tracciamento realmente attivati sul sito. Non dichiarare strumenti assenti o tempi di conservazione inventati.
