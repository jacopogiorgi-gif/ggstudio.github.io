# Guida pratica — GG Studio Giorgi su Google Sites

**Il sito Next.js presente nel progetto è una possibile anteprima, non un file caricabile su Google Sites.** Per pubblicare su Google Sites, ricrea le sezioni nell'editor con i blocchi nativi e segui questa guida. Il prompt da copiare è in [`PROMPT_SITO.md`](../PROMPT_SITO.md), i testi pronti sono in [`CONTENUTI.md`](CONTENUTI.md).

## 1. Prepara il sito e i materiali

1. Vai su [sites.google.com/new](https://sites.google.com/new), crea un sito vuoto e chiamalo **GG Studio Giorgi**.
2. Crea nel pannello **Pagine**: **Home**, **Lo Studio**, **Competenze**, **News**, **Contatti** e **Privacy**. Metti Privacy nel footer o come pagina non evidenziata nella navigazione principale, ma sempre raggiungibile.
3. In **Temi** scegli un tema sobrio con carattere sans-serif e usa bianco, grigio chiarissimo (`#F4F6F5`) e blu del logo (circa `#213B63`). Usa spazi generosi, sezioni alternate chiare/blu e pulsanti con testo breve. Evita animazioni non necessarie.
4. Carica **direttamente in Google Sites** il PNG originale del logo allegato alla richiesta. Conserva il file originale senza ridisegni o modifiche. Se il logo nell'header risulta troppo piccolo, aggiungilo anche nella prima sezione come immagine con proporzioni bloccate.
5. Carica direttamente in Google Sites le **foto originali fornite nella richiesta**. In questo ambiente non sono state consegnate come file riutilizzabili: le vecchie immagini d'archivio della demo Next.js **non sostituiscono** gli allegati originali. Non usare foto stock.

### Dove collocare le foto originali

| Foto riconoscibile | Collocazione consigliata | Testo alternativo suggerito |
| --- | --- | --- |
| Sala riunioni con tavolo bianco e quadro colorato | Hero Home / anteprima Lo Studio | Sala riunioni di GG Studio Giorgi a Prato |
| Corridoio con grande quadro fotografico | Galleria Lo Studio | Corridoio dello Studio con opera d'arte |
| Passaggio con arco e quadro appoggiato | Galleria Lo Studio | Passaggio interno e opere d'arte nello Studio |
| Arco in mattoni con decorazione luminosa stagionale | Galleria Lo Studio, non hero permanente | Ingresso interno dello Studio con arco in mattoni |
| Parete esterna con monogramma GG | Sezione “Dove siamo” / Studio | Dettaglio dell'ingresso di GG Studio Giorgi |
| Ufficio con scrivania scura | Galleria Lo Studio | Ufficio professionale di GG Studio Giorgi |
| Postazioni di lavoro con pianta | Galleria Lo Studio | Postazioni di lavoro all'interno dello Studio |

Non duplicare le foto ripetute nella richiesta. Mantieni le persone, le opere e le caratteristiche architettoniche come nelle immagini originali; ritaglia soltanto se necessario per adattare il blocco, senza deformare.

## 2. Costruisci le pagine con i blocchi nativi

| Pagina | Sequenza consigliata in Google Sites |
| --- | --- |
| Home | Intestazione con logo e foto sala riunioni → titolo e due pulsanti → testo “Oltre i numeri” → griglia 3×2 competenze → anteprima foto Studio → widget ultime 3 news → call to action contatti |
| Lo Studio | Intestazione con foto corridoio → breve presentazione → galleria foto reali con didascalie → pulsante Contatti |
| Competenze | Intestazione testuale → sezioni/riquadri per sei aree → invito a fissare un incontro |
| News | Titolo e introduzione → widget news completo dal Foglio Google → messaggio se vuoto |
| Contatti | Titolo → recapiti + orari → Modulo Google incorporato → blocco Google Maps → quattro pulsanti social |
| Privacy | Informativa verificata dallo Studio e collegata al modulo e al footer |

Per i testi usa [`CONTENUTI.md`](CONTENUTI.md). Inserisci pulsanti e link creati dall'editor di Sites; non usare HTML per imitare pulsanti non cliccabili. Verifica l'anteprima su telefono, tablet e desktop.

### Social ufficiali

Crea quattro link o pulsanti, nel footer e in Contatti:

- Facebook — https://www.facebook.com/studiogiorgi.giorgi/
- Instagram — https://www.instagram.com/ggstudiogiorgi/
- YouTube — https://www.youtube.com/@ggstudiogiorgi
- TikTok — https://www.tiktok.com/@ggstudiogiorgi

I recapiti devono essere cliccabili: telefono `tel:+390574572757`, email `mailto:info@ggstudio.tax`.

## 3. Modulo contatti: Google Moduli, non un form finto

1. Crea un nuovo modulo in [forms.google.com](https://forms.google.com/) dal titolo **Contatta GG Studio Giorgi**. Nella descrizione scrivi che i dati sono usati per rispondere alla richiesta e inserisci il **link effettivo** alla pagina Privacy pubblicata.
2. Crea questi campi: **Nome e cognome** (risposta breve, obbligatorio), **Indirizzo email** (risposta breve, obbligatorio, con convalida “indirizzo email”), **Telefono** (risposta breve, facoltativo), **Argomento** (elenco a discesa: Fiscale e tributaria / Contabile / Societaria / Aziendale e finanziaria / Altro; obbligatorio), **Messaggio** (paragrafo, obbligatorio), **Conferma privacy** (casella di controllo obbligatoria con unica opzione “Ho letto l'informativa privacy e acconsento all'uso dei dati per rispondere alla mia richiesta”).
3. In **Impostazioni** verifica che il modulo sia accessibile ai visitatori desiderati. Se vuoi permettere contatti senza account Google, non attivare “Limita a 1 risposta”, non aggiungere campi di caricamento file e non richiedere email Google verificate. Se usi già la domanda Email, evita di raccoglierla una seconda volta nelle impostazioni.
4. Personalizza il messaggio di conferma: **“Grazie per averci scritto. Abbiamo ricevuto la tua richiesta e ti risponderemo appena possibile.”**
5. In **Risposte** collega un Foglio Google **privato**; non incorporare mai il foglio delle risposte nel sito pubblico. Nello stesso menu delle Risposte, attiva **Ricevi notifiche email per le nuove risposte**. Le notifiche native vanno al proprietario/account che le attiva: usa o coinvolgi l'account che deve effettivamente riceverle; non presumere che arrivino automaticamente a `info@ggstudio.tax` se il proprietario è diverso.
6. Se il proprietario del modulo usa un altro account e vuoi inviare ogni nuova richiesta a **info@ggstudio.tax**, puoi usare lo script facoltativo [`contatti/Notifiche.gs`](contatti/Notifiche.gs): apri l'editor Apps Script **dal Modulo Google**, incolla lo script, salva ed esegui `installContactTrigger` una sola volta autorizzando l'accesso. Non serve distribuirlo come web app. Il trigger invierà a `info@ggstudio.tax` una notifica con le risposte e userà l'email del visitatore come `reply-to`, se valida. Fai un invio di prova; se ricevi doppie notifiche, disattiva quelle native nell'account che non ne ha bisogno.
7. Pubblica il modulo se richiesto dall'interfaccia. In Google Sites, pagina **Contatti → Inserisci → Moduli**, scegli il modulo e regola la sua altezza finché il pulsante Invia non viene tagliato. Fai un invio di prova e controlla la risposta.

**Privacy:** la bozza in `CONTENUTI.md` non sostituisce la verifica legale dell'informativa, in particolare per titolarità, tempi di conservazione, base giuridica e servizi Google usati.

## 4. Mappa Google Maps

Nella pagina **Contatti**, usa **Inserisci → Mappa** e cerca **Via Giuseppe Verdi 18, 59100 Prato (PO)**. Controlla il punto prima della pubblicazione. Aggiungi un pulsante “Indicazioni stradali” che apre:

https://www.google.com/maps/search/?api=1&query=Via+Giuseppe+Verdi+18%2C+59100+Prato

Non serve una chiave API per il blocco Mappa nativo di Google Sites.

## 5. News aggiornabili da Google Sheets

La soluzione con aggiornamento automatico è inclusa in [`news/Code.gs`](news/Code.gs) e [`news/Index.html`](news/Index.html). Non incollare questi file direttamente in “Incorpora codice” di Sites: sono un **web app Google Apps Script** che va prima pubblicata, poi incorporata tramite URL.

1. Crea un Foglio Google chiamato **GG Studio Giorgi — News**. Rinomina la prima scheda **News** e usa queste intestazioni esatte in riga 1: **Data | Categoria | Titolo | Sommario | Testo | Stato**.
2. Scrivi ogni articolo su una riga. Usa una vera data nella colonna **Data** e in **Stato** scrivi `BOZZA` finché non vuoi pubblicare, oppure `PUBBLICATO` per renderlo visibile. Non inserire dati riservati nel foglio news: i contenuti pubblicati diventano visibili a tutti.
3. Copia l'ID del Foglio dall'URL: `https://docs.google.com/spreadsheets/d/ID_DEL_FOGLIO/edit`.
4. Apri **Estensioni → Apps Script** dal Foglio, sostituisci il contenuto di `Code.gs` con il file fornito, sostituisci `INCOLLA_ID_DEL_FOGLIO` con l'ID e aggiungi un file **HTML** chiamato `Index` con il contenuto di `news/Index.html`.
5. Salva. Dal menu **Distribuisci → Nuovo deployment → Applicazione web**, imposta **Esegui come: me** e **Chi può accedere: chiunque** (se la policy del tuo account lo consente). Autorizza gli accessi al Foglio. Copia l'URL pubblico terminante in `/exec`, non quello di test `/dev`.
6. In Home usa **Inserisci → Incorpora → URL**, incolla l'URL `/exec` e imposta altezza indicativa di **480–550 px**: mostra le ultime tre news. Nella pagina News incorpora lo stesso URL con `?view=all` e assegna un'altezza indicativa di **1000–1400 px**; il contenuto è scrollabile nel riquadro se cresce.
7. Quando cambi una riga nel Foglio da `BOZZA` a `PUBBLICATO` o aggiorni il testo, la news appare al successivo caricamento della pagina **senza ripubblicare Google Sites**. Per modificare il codice Apps Script, aggiorna invece il deployment a una nuova versione.
8. Prova entrambi gli incorporamenti in finestra anonima. Se non si vedono, verifica accesso “Chiunque” del web app, autorizzazioni e policy dell'account. Il Foglio può restare privato: il web app legge solo le colonne delle news pubblicate ed è eseguito dal proprietario.

Google Sites non crea automaticamente pagine indicizzabili separate per ciascuna riga del Foglio. Il widget mostra le news nel riquadro incorporato con “Leggi il testo” espandibile; per articoli SEO con URL propri crea pagine native aggiuntive in Sites e collegale manualmente.

## 6. Dominio e controlli finali

- **Impostazioni → Domini personalizzati**: collega `ggstudio.tax` seguendo le indicazioni del provider e verificando la proprietà. Se Google Sites richiede un sottodominio come `www.ggstudio.tax`, configura quello e gestisci il reindirizzamento del dominio principale presso il registrar. Non cambiare i DNS della posta senza verificarli.
- Controlla logo originale, ortografia, orari, quattro link social, email e telefono cliccabili, indirizzo della mappa, invio del modulo e visibilità pubblica delle news.
- Usa testi alternativi per le immagini dove l'editor lo consente, buon contrasto cromatico e titoli ordinati. Controlla l'anteprima mobile prima di premere **Pubblica**.

### Documentazione ufficiale

- [Google Sites: inserire Moduli, Maps e contenuti web](https://support.google.com/sites/answer/90569?hl=it)
- [Google Apps Script: web app incorporabili in Sites](https://developers.google.com/apps-script/guides/web)
- [Google Moduli: notifiche e risposte](https://support.google.com/docs/answer/139706?hl=it)
- [Google Sites: dominio personalizzato](https://support.google.com/sites/answer/9068867?hl=it)
