import { SiFacebook, SiInstagram, SiTiktok, SiYoutube } from "react-icons/si";
import type { IconType } from "react-icons";
import { socialLinks } from "@/lib/site";

const icons: Record<(typeof socialLinks)[number]["name"], IconType> = {
  Facebook: SiFacebook,
  Instagram: SiInstagram,
  YouTube: SiYoutube,
  TikTok: SiTiktok,
};

export function SocialLinks({ className = "" }: { className?: string }) {
  return (
    <div className={`social-links ${className}`} aria-label="Social media">
      {socialLinks.map((social) => {
        const Icon = icons[social.name];
        return <a key={social.name} href={social.href} target="_blank" rel="noopener noreferrer" aria-label={social.label} title={social.label}><Icon size={17} aria-hidden="true" /></a>;
      })}
    </div>
  );
}
