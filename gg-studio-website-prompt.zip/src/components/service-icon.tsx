import { ArrowRightLeft, Building2, Calculator, ChartNoAxesCombined, Compass, ShieldCheck } from "lucide-react";

export function ServiceIcon({ name, size = 27 }: { name: string; size?: number }) {
  const props = { size, strokeWidth: 1.5, "aria-hidden": true as const };
  switch (name) {
    case "chart": return <ChartNoAxesCombined {...props} />;
    case "calculator": return <Calculator {...props} />;
    case "building": return <Building2 {...props} />;
    case "compass": return <Compass {...props} />;
    case "arrows": return <ArrowRightLeft {...props} />;
    default: return <ShieldCheck {...props} />;
  }
}
