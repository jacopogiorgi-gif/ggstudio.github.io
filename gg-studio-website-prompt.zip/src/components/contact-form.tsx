"use client";

import { useState, type FormEvent } from "react";
import Link from "next/link";
import { ArrowUpRight, CheckCircle2, LoaderCircle } from "lucide-react";

type FormStatus = "idle" | "sending" | "success" | "error";

export function ContactForm() {
  const [status, setStatus] = useState<FormStatus>("idle");
  const [error, setError] = useState("");

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = event.currentTarget;
    const data = new FormData(form);
    setStatus("sending");
    setError("");
    try {
      const response = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: data.get("name"),
          email: data.get("email"),
          phone: data.get("phone"),
          subject: data.get("subject"),
          message: data.get("message"),
          privacyAccepted: data.get("privacy") === "on",
          website: data.get("website"),
        }),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Non siamo riusciti a inviare il messaggio. Riprova.");
      form.reset();
      setStatus("success");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Si è verificato un errore. Riprova più tardi.");
      setStatus("error");
    }
  }

  return (
    <form className="contact-form" onSubmit={handleSubmit}>
      <div className="form-heading"><span>01 / SCRIVICI UN MESSAGGIO</span><h2>Raccontaci di te.</h2><p>Compila il modulo e ti risponderemo appena possibile.</p></div>
      <div className="form-fields">
        <div className="form-field"><label htmlFor="contact-name">Nome e cognome <span>*</span></label><input id="contact-name" name="name" type="text" autoComplete="name" placeholder="Il tuo nome" maxLength={160} required /></div>
        <div className="form-field"><label htmlFor="contact-email">Indirizzo email <span>*</span></label><input id="contact-email" name="email" type="email" autoComplete="email" placeholder="nome@esempio.it" maxLength={254} required /></div>
        <div className="form-field"><label htmlFor="contact-phone">Telefono</label><input id="contact-phone" name="phone" type="tel" autoComplete="tel" placeholder="Il tuo numero" maxLength={40} /></div>
        <div className="form-field"><label htmlFor="contact-subject">Di cosa vuoi parlarci? <span>*</span></label><select id="contact-subject" name="subject" defaultValue="" required><option value="" disabled>Seleziona un argomento</option><option>Consulenza fiscale e tributaria</option><option>Consulenza contabile</option><option>Consulenza societaria</option><option>Consulenza aziendale</option><option>Altro / informazioni generali</option></select></div>
        <div className="form-field form-field-wide"><label htmlFor="contact-message">Il tuo messaggio <span>*</span></label><textarea id="contact-message" name="message" rows={6} placeholder="Scrivi qui il tuo messaggio..." minLength={10} maxLength={4000} required /></div>
      </div>
      <div className="honeypot" aria-hidden="true"><label htmlFor="contact-website">Non compilare questo campo</label><input id="contact-website" name="website" type="text" tabIndex={-1} autoComplete="off" /></div>
      <label className="privacy-check"><input name="privacy" type="checkbox" required /><span>Ho letto l’<Link href="/privacy" target="_blank">informativa sulla privacy</Link> e acconsento al trattamento dei miei dati per rispondere alla richiesta. <span className="required">*</span></span></label>
      <div className="form-submit-row"><button className="button button-dark" type="submit" disabled={status === "sending"}>{status === "sending" ? <>Invio in corso <LoaderCircle size={17} className="spinner" /></> : <>Invia il messaggio <ArrowUpRight size={18} /></>}</button><span>* Campi obbligatori</span></div>
      <div aria-live="polite" role="status">{status === "success" && <p className="form-feedback success"><CheckCircle2 size={20} /> Grazie! Abbiamo ricevuto il tuo messaggio e ti risponderemo al più presto.</p>}{status === "error" && <p className="form-feedback error">{error}</p>}</div>
    </form>
  );
}
