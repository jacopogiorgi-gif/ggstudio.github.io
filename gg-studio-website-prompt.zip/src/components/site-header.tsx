"use client";

import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { ArrowUpRight, Mail, MapPin, Menu, Phone, X } from "lucide-react";
import { navigation, site } from "@/lib/site";

export function SiteHeader() {
  const pathname = usePathname();
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => setMenuOpen(false), [pathname]);

  return (
    <>
      <div className="topbar">
        <div className="site-container topbar-inner">
          <span className="topbar-place"><MapPin size={13} strokeWidth={1.8} /> Nel cuore di Prato, al fianco della tua impresa</span>
          <div className="topbar-contact">
            <a href={site.phoneHref}><Phone size={13} strokeWidth={1.8} /> {site.phone}</a>
            <span className="topbar-divider" />
            <a href={site.emailHref}><Mail size={13} strokeWidth={1.8} /> {site.email}</a>
          </div>
        </div>
      </div>
      <header className="site-header">
        <div className="site-container header-inner">
          <Link href="/" className="brand-link" aria-label="GG Studio Giorgi, torna alla homepage">
            <Image src="/images/logo-sticky.png" alt="GG Studio Giorgi — Professionisti per l’impresa" width={250} height={138} className="brand-image" priority />
          </Link>
          <nav className="desktop-nav" aria-label="Navigazione principale">
            {navigation.map((item) => {
              const active = pathname === item.href || (item.href !== "/" && pathname.startsWith(`${item.href}/`));
              return <Link key={item.href} href={item.href} className={active ? "nav-link active" : "nav-link"} aria-current={active ? "page" : undefined}>{item.label}</Link>;
            })}
          </nav>
          <Link href="/contatti" className="header-cta">Parliamone <ArrowUpRight size={17} strokeWidth={1.8} /></Link>
          <button type="button" className="menu-toggle" aria-label={menuOpen ? "Chiudi il menu" : "Apri il menu"} aria-expanded={menuOpen} aria-controls="mobile-navigation" onClick={() => setMenuOpen(!menuOpen)}>
            {menuOpen ? <X size={27} strokeWidth={1.5} /> : <Menu size={27} strokeWidth={1.5} />}
          </button>
        </div>
        <nav id="mobile-navigation" className={menuOpen ? "mobile-nav open" : "mobile-nav"} aria-label="Navigazione mobile" inert={!menuOpen}>
          {navigation.map((item, index) => <Link key={item.href} href={item.href} onClick={() => setMenuOpen(false)}><span>0{index + 1}</span>{item.label}<ArrowUpRight size={18} /></Link>)}
          <div className="mobile-nav-contact"><a href={site.phoneHref}>{site.phone}</a><a href={site.emailHref}>{site.email}</a></div>
        </nav>
      </header>
    </>
  );
}
