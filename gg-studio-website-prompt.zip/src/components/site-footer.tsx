import Image from "next/image";
import Link from "next/link";
import { ArrowUpRight, MapPin } from "lucide-react";
import { navigation, openingHours, site } from "@/lib/site";
import { SocialLinks } from "./social-links";

export function SiteFooter() {
  return (
    <footer className="site-footer">
      <div className="site-container footer-main">
        <div className="footer-about">
          <Link href="/" className="footer-logo" aria-label="GG Studio Giorgi, homepage"><Image src="/images/logo-sticky.png" alt="GG Studio Giorgi — Professionisti per l’impresa" width={250} height={138} /></Link>
          <p>Una visione d’insieme, un’attenzione personale. Al fianco delle imprese e delle persone, ogni giorno.</p>
          <SocialLinks className="footer-socials" />
        </div>
        <div className="footer-column">
          <h3>Esplora</h3>
          {navigation.map((item) => <Link key={item.href} href={item.href}>{item.label}</Link>)}
        </div>
        <div className="footer-column footer-contact">
          <h3>Vieni a trovarci</h3>
          <a href={site.mapsLink} target="_blank" rel="noopener noreferrer" className="footer-address"><MapPin size={16} strokeWidth={1.6} /> <span>Via Giuseppe Verdi n. 18<br />59100 Prato (PO)</span></a>
          <a href={site.phoneHref}>{site.phone}</a>
          <a href={site.emailHref}>{site.email}</a>
          <Link href="/contatti" className="footer-direction">Indicazioni e contatti <ArrowUpRight size={15} /></Link>
        </div>
        <div className="footer-column footer-hours">
          <h3>Orari di apertura</h3>
          {openingHours.map((item) => <div className="footer-hour" key={item.day}><span>{item.day}</span><span>{item.hours}</span></div>)}
        </div>
      </div>
      <div className="site-container footer-bottom">
        <span>© {new Date().getFullYear()} GG Studio Giorgi. Tutti i diritti riservati.</span>
        <div><Link href="/privacy">Privacy</Link><Link href="/admin" rel="nofollow">Area riservata</Link><span>Made with care in Prato.</span></div>
      </div>
    </footer>
  );
}
