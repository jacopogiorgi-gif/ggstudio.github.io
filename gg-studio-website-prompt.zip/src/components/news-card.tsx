import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import type { articles } from "@/db/schema";
import { formatItalianDate } from "@/lib/site";

type ArticleCardData = Pick<typeof articles.$inferSelect, "slug" | "title" | "excerpt" | "category" | "publishedAt" | "createdAt">;

export function NewsCard({ article, index }: { article: ArticleCardData; index?: number }) {
  return (
    <Link href={`/news/${article.slug}`} className="news-card">
      <div className="news-card-top"><span className="news-card-category">{article.category}</span><span className="news-card-number">{String((index ?? 0) + 1).padStart(2, "0")}</span></div>
      <div className="news-card-content"><time dateTime={(article.publishedAt ?? article.createdAt).toISOString()}>{formatItalianDate(article.publishedAt ?? article.createdAt)}</time><h3>{article.title}</h3><p>{article.excerpt}</p></div>
      <div className="news-card-foot"><span>Leggi l’articolo</span><span className="news-card-arrow"><ArrowUpRight size={18} strokeWidth={1.7} /></span></div>
    </Link>
  );
}
