import Link from "next/link";
import { ArrowLeft, ArrowUpRight } from "lucide-react";

export default function NotFound() {
  return <main className="min-h-[65vh] bg-[#f4f6f5] py-24"><div className="site-container"><p className="eyebrow">PAGINA NON TROVATA</p><div className="mb-5 font-['Playfair_Display'] text-[clamp(100px,18vw,230px)] leading-none italic tracking-[-.08em] text-[#c4d1da]">404</div><h1 className="max-w-[600px] text-[clamp(36px,5vw,58px)] font-medium leading-[1.15] tracking-[-.055em]">Questa strada non porta dove cercavi.</h1><p className="my-6 max-w-[480px] leading-7 text-[#586474]">Nessun problema: possiamo tornare all’inizio e trovare insieme la direzione giusta.</p><div className="flex flex-wrap items-center gap-7"><Link href="/" className="button button-dark"><ArrowLeft size={17} /> Torna alla homepage</Link><Link href="/contatti" className="underlined-link">Contattaci <ArrowUpRight size={17} /></Link></div></div></main>;
}
