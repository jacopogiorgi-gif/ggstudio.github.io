import type { MetadataRoute } from "next";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { articles } from "@/db/schema";

export const dynamic = "force-dynamic";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = "https://ggstudio.tax";
  const paths = ["/", "/studio", "/competenze", "/news", "/contatti", "/privacy"];
  const news = await db.select({ slug: articles.slug, updatedAt: articles.updatedAt }).from(articles).where(eq(articles.published, true)).orderBy(desc(articles.publishedAt));
  return [
    ...paths.map((path) => ({ url: `${base}${path}`, changeFrequency: "monthly" as const, priority: path === "/" ? 1 : path === "/privacy" ? 0.2 : 0.7 })),
    ...news.map((item) => ({ url: `${base}/news/${item.slug}`, lastModified: item.updatedAt, changeFrequency: "monthly" as const, priority: 0.6 })),
  ];
}
