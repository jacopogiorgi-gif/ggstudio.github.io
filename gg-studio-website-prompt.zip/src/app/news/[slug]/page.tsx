import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, ArrowUpRight, Clock3 } from "lucide-react";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { articles } from "@/db/schema";
import { formatItalianDate } from "@/lib/site";

export const dynamic = "force-dynamic";

async function getArticle(slug: string) {
  const [article] = await db.select().from(articles).where(and(eq(articles.slug, slug), eq(articles.published, true))).limit(1);
  return article;
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const article = await getArticle(slug);
  return article ? { title: article.title, description: article.excerpt } : { title: "Articolo non trovato" };
}

export default async function ArticlePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const article = await getArticle(slug);
  if (!article) notFound();
  const blocks = article.body.split(/\n\s*\n/).map((block) => block.trim()).filter(Boolean);

  return (
    <main>
      <section className="article-header"><div className="site-container article-header-inner"><Link href="/news" className="article-back"><ArrowLeft size={17} /> Torna alle news</Link><div className="article-meta"><span>{article.category}</span><span className="article-meta-dot" /><time dateTime={(article.publishedAt ?? article.createdAt).toISOString()}>{formatItalianDate(article.publishedAt ?? article.createdAt)}</time></div><h1>{article.title}</h1><p>{article.excerpt}</p></div></section>
      <section className="article-section"><div className="site-container article-layout"><aside className="article-aside"><span>DALLO STUDIO</span><strong>GG Studio Giorgi</strong><span className="article-read-time"><Clock3 size={16} /> {Math.max(1, Math.ceil(article.body.split(/\s+/).length / 200))} min di lettura</span></aside><article className="article-body">{blocks.map((block, index) => block.startsWith("## ") ? <h2 key={index}>{block.slice(3)}</h2> : <p key={index}>{block}</p>)}<div className="article-signature"><span>GG STUDIO GIORGI</span><p>Professionisti per l’impresa.</p></div></article></div></section>
      <section className="article-footer-nav"><div className="site-container"><Link href="/news" className="underlined-link"><ArrowLeft size={17} /> Tutte le news</Link><Link href="/contatti" className="underlined-link">Hai una domanda? Contattaci <ArrowUpRight size={17} /></Link></div></section>
    </main>
  );
}
