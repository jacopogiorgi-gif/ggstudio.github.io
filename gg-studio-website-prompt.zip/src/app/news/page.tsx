import type { Metadata } from "next";
import Link from "next/link";
import { ArrowUpRight, Newspaper } from "lucide-react";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { articles } from "@/db/schema";
import { NewsCard } from "@/components/news-card";

export const dynamic = "force-dynamic";
export const metadata: Metadata = {
  title: "News e approfondimenti",
  description: "News, spunti e approfondimenti di GG Studio Giorgi per imprese e professionisti.",
};

export default async function NewsPage({ searchParams }: { searchParams: Promise<{ categoria?: string }> }) {
  const { categoria } = await searchParams;
  const published = await db.select().from(articles).where(eq(articles.published, true)).orderBy(desc(articles.publishedAt));
  const categories = Array.from(new Set(published.map((item) => item.category)));
  const selectedCategory = categories.includes(categoria ?? "") ? categoria : undefined;
  const visible = selectedCategory ? published.filter((item) => item.category === selectedCategory) : published;

  return (
    <main>
      <section className="page-intro news-page-intro"><div className="site-container page-intro-inner"><p className="eyebrow">DALLO STUDIO <span className="eyebrow-dot">·</span> NEWS</p><h1>Idee, novità<br />e <em>punti di vista.</em></h1><p>Uno spazio per condividere ciò che cambia, ciò che ispira e ciò che può fare la differenza per la tua impresa.</p><div className="page-intro-index">GG / 03 <span>NEWS & APPROFONDIMENTI</span></div></div><span className="news-hero-watermark" aria-hidden="true">N.</span></section>
      <section className="news-list-section section-space"><div className="site-container"><div className="news-list-heading"><div><p className="eyebrow">IL NOSTRO DIARIO</p><h2 className="section-title">Da leggere <em>con calma.</em></h2></div><span className="news-count">{String(published.length).padStart(2, "0")} ARTICOLI</span></div>
        {published.length > 0 ? <><nav className="news-filters" aria-label="Filtra le news"><Link href="/news" className={!selectedCategory ? "selected" : ""}>Tutti</Link>{categories.map((category) => <Link key={category} href={`/news?categoria=${encodeURIComponent(category)}`} className={selectedCategory === category ? "selected" : ""}>{category}</Link>)}</nav><div className="news-grid news-grid-page">{visible.map((article, index) => <NewsCard key={article.id} article={article} index={index} />)}</div></> : <div className="news-empty-page"><span className="news-empty-icon"><Newspaper size={35} strokeWidth={1.3} /></span><span className="news-empty-small">STIAMO PREPARANDO QUALCOSA DI INTERESSANTE</span><h3>Le novità stanno <em>arrivando.</em></h3><p>Questo spazio ospiterà news e approfondimenti dallo Studio. Torna a trovarci presto o scrivici per restare in contatto.</p><Link href="/contatti" className="button button-dark">Scrivici <ArrowUpRight size={17} /></Link></div>}
      </div></section>
      <section className="news-end-cta"><div className="site-container"><span>UNA DOMANDA? PARLIAMONE.</span><p>Siamo qui per aiutarti a trovare le risposte giuste.</p><Link href="/contatti" className="underlined-link">Contattaci <ArrowUpRight size={17} /></Link></div></section>
    </main>
  );
}
