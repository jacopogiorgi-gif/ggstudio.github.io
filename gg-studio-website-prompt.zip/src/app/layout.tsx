import type { Metadata } from "next";
import type { ReactNode } from "react";
import "@fontsource/dm-sans/400.css";
import "@fontsource/dm-sans/500.css";
import "@fontsource/dm-sans/600.css";
import "@fontsource/dm-sans/700.css";
import "@fontsource/playfair-display/400-italic.css";
import "./globals.css";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";

export const metadata: Metadata = {
  metadataBase: new URL("https://ggstudio.tax"),
  title: { default: "GG Studio Giorgi | Professionisti per l’impresa", template: "%s | GG Studio Giorgi" },
  description: "GG Studio Giorgi, Studio di Dottori Commercialisti a Prato: consulenza fiscale, contabile, societaria e aziendale. Via Giuseppe Verdi 18, Prato.",
  openGraph: {
    type: "website",
    locale: "it_IT",
    siteName: "GG Studio Giorgi",
    title: "GG Studio Giorgi | Professionisti per l’impresa",
    description: "Consulenza e visione per la tua impresa, nel cuore di Prato.",
    images: [{ url: "/images/studio-archivio.jpg", width: 1568, height: 572, alt: "GG Studio Giorgi a Prato" }],
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="it">
      <body>
        <SiteHeader />
        {children}
        <SiteFooter />
      </body>
    </html>
  );
}
