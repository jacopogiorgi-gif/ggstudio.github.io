import type { Metadata } from "next";
import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { ArrowLeft, ArrowUpRight } from "lucide-react";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { articles } from "@/db/schema";
import { isAdmin } from "@/lib/admin-auth";
import { updateArticleAction } from "../../actions";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Modifica articolo", robots: { index: false, follow: false } };

export default async function EditArticlePage({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ errore?: string }> }) {
  if (!(await isAdmin())) redirect("/admin");
  const { id } = await params;
  const { errore } = await searchParams;
  const articleId = Number(id);
  if (!Number.isInteger(articleId) || articleId < 1) notFound();
  const [article] = await db.select().from(articles).where(eq(articles.id, articleId)).limit(1);
  if (!article) notFound();

  return <main className="admin-page"><div className="site-container admin-edit-container"><Link href="/admin" className="article-back"><ArrowLeft size={17} /> Torna all’area riservata</Link><div className="admin-heading"><div><p className="eyebrow">AREA RISERVATA <span className="eyebrow-dot">·</span> MODIFICA</p><h1>Modifica <em>l’articolo.</em></h1><p>Aggiorna il contenuto e scegli se renderlo visibile sul sito.</p></div></div>{errore && <p className="admin-notice error">Controlla i campi richiesti e riprova.</p>}<section className="admin-panel"><form action={updateArticleAction} className="admin-editor-form"><input type="hidden" name="id" value={article.id} /><div className="form-field"><label htmlFor="edit-title">Titolo</label><input id="edit-title" name="title" defaultValue={article.title} minLength={5} maxLength={240} required /></div><div className="form-field"><label htmlFor="edit-category">Categoria</label><input id="edit-category" name="category" defaultValue={article.category} maxLength={80} required /></div><div className="form-field"><label htmlFor="edit-excerpt">Introduzione breve</label><textarea id="edit-excerpt" name="excerpt" rows={3} defaultValue={article.excerpt} minLength={10} maxLength={800} required /></div><div className="form-field"><label htmlFor="edit-body">Testo dell’articolo</label><textarea id="edit-body" name="body" rows={16} defaultValue={article.body} minLength={20} maxLength={30000} required /></div><label className="admin-publish-check"><input type="checkbox" name="published" defaultChecked={article.published} /> Pubblicato sul sito</label><div className="admin-edit-actions"><button type="submit" className="button button-dark">Salva modifiche <ArrowUpRight size={17} /></button><Link href="/admin" className="underlined-link">Annulla</Link></div></form></section></div></main>;
}
