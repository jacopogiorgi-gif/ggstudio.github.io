"use server";

import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { articles, contactMessages } from "@/db/schema";
import { ADMIN_COOKIE, adminCookieOptions, createAdminSession, isAdmin, verifyPassword } from "@/lib/admin-auth";

function field(formData: FormData, key: string) {
  return String(formData.get(key) ?? "").trim();
}

async function requireAdmin() {
  if (!(await isAdmin())) redirect("/admin");
}

function slugify(value: string) {
  return value.normalize("NFKD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 175);
}

function validArticle(title: string, excerpt: string, body: string, category: string) {
  return title.length >= 5 && title.length <= 240 && excerpt.length >= 10 && excerpt.length <= 800 && body.length >= 20 && body.length <= 30000 && category.length >= 2 && category.length <= 80;
}

export async function loginAction(formData: FormData) {
  const password = field(formData, "password");
  if (!verifyPassword(password)) redirect("/admin?errore=password");
  const store = await cookies();
  store.set(ADMIN_COOKIE, createAdminSession(), adminCookieOptions);
  redirect("/admin");
}

export async function logoutAction() {
  const store = await cookies();
  store.delete(ADMIN_COOKIE);
  redirect("/admin");
}

export async function createArticleAction(formData: FormData) {
  await requireAdmin();
  const title = field(formData, "title");
  const excerpt = field(formData, "excerpt");
  const body = field(formData, "body");
  const category = field(formData, "category") || "News";
  const published = formData.get("published") === "on";
  if (!validArticle(title, excerpt, body, category)) redirect("/admin?errore=campi");
  let slug = slugify(title) || "articolo";
  const [existing] = await db.select({ id: articles.id }).from(articles).where(eq(articles.slug, slug)).limit(1);
  if (existing) slug = `${slug.slice(0, 165)}-${Date.now().toString(36)}`;
  await db.insert(articles).values({ slug, title, excerpt, body, category, published, publishedAt: published ? new Date() : null });
  revalidatePath("/");
  revalidatePath("/news");
  redirect("/admin?salvato=1");
}

export async function updateArticleAction(formData: FormData) {
  await requireAdmin();
  const id = Number(field(formData, "id"));
  if (!Number.isInteger(id) || id < 1) redirect("/admin?errore=articolo");
  const [old] = await db.select().from(articles).where(eq(articles.id, id)).limit(1);
  if (!old) redirect("/admin?errore=articolo");
  const title = field(formData, "title");
  const excerpt = field(formData, "excerpt");
  const body = field(formData, "body");
  const category = field(formData, "category") || "News";
  const published = formData.get("published") === "on";
  if (!validArticle(title, excerpt, body, category)) redirect(`/admin/news/${id}?errore=campi`);
  await db.update(articles).set({ title, excerpt, body, category, published, publishedAt: published ? (old.publishedAt ?? new Date()) : null, updatedAt: new Date() }).where(eq(articles.id, id));
  revalidatePath("/");
  revalidatePath("/news");
  revalidatePath(`/news/${old.slug}`);
  redirect("/admin?salvato=1");
}

export async function deleteArticleAction(formData: FormData) {
  await requireAdmin();
  const id = Number(field(formData, "id"));
  if (!Number.isInteger(id) || id < 1) redirect("/admin?errore=articolo");
  const [old] = await db.select().from(articles).where(eq(articles.id, id)).limit(1);
  if (old) {
    await db.delete(articles).where(eq(articles.id, id));
    revalidatePath("/");
    revalidatePath("/news");
    revalidatePath(`/news/${old.slug}`);
  }
  redirect("/admin?eliminato=1");
}

export async function markMessageReadAction(formData: FormData) {
  await requireAdmin();
  const id = Number(field(formData, "id"));
  if (Number.isInteger(id) && id > 0) await db.update(contactMessages).set({ readAt: new Date() }).where(eq(contactMessages.id, id));
  revalidatePath("/admin");
  redirect("/admin?messaggio=letto");
}
