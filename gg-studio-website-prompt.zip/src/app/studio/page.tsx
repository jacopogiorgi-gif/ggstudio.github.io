import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { ArrowRight, ArrowUpRight } from "lucide-react";
import { gallery } from "@/lib/site";

export const metadata: Metadata = {
  title: "Lo studio",
  description: "Scopri GG Studio Giorgi, il nostro approccio e gli spazi dello Studio nel cuore di Prato.",
};

export default function StudioPage() {
  return (
    <main>
      <section className="subhero studio-subhero">
        <div className="subhero-copy"><div className="subhero-copy-inner"><p className="eyebrow">CHI SIAMO <span className="eyebrow-dot">·</span> GG STUDIO GIORGI</p><h1>Prima di tutto,<br /><em>le persone.</em></h1><p>Crediamo che la consulenza migliore nasca da una relazione autentica. Ascoltare, comprendere, trovare insieme la strada giusta.</p><a href="#la-nostra-storia" className="underlined-link">Scopri la nostra storia <ArrowRight size={17} /></a></div></div>
        <div className="subhero-image"><Image src="/images/studio-archivio.jpg" alt="Insegna di GG Studio Giorgi a Prato" fill priority sizes="(max-width: 800px) 100vw, 50vw" /><span className="subhero-image-label">GG STUDIO GIORGI / PRATO</span></div>
      </section>

      <section className="studio-intro section-space" id="la-nostra-storia"><div className="site-container studio-intro-grid"><div><p className="eyebrow">LA NOSTRA STORIA</p><h2 className="section-title">Una storia giovane.<br /><em>Un’esperienza solida.</em></h2></div><div className="studio-intro-text"><p className="intro-lead">GG Studio Giorgi nasce nel 2019 dall’incontro tra esperienza professionale e voglia di fare le cose in modo diverso.</p><p>Abbiamo scelto di essere un punto di riferimento per imprese, professionisti, persone ed enti del terzo settore. Un luogo in cui competenze diverse si incontrano per affrontare insieme le sfide economiche, fiscali e finanziarie.</p><p>Per noi ogni cliente è una storia a sé. È per questo che mettiamo al centro il dialogo, la chiarezza e la cura di ogni dettaglio.</p></div></div></section>

      <section className="quote-band"><div className="site-container quote-band-inner"><span>IL NOSTRO PUNTO DI VISTA</span><blockquote>“Non ci limitiamo a guardare i numeri. Guardiamo <em>le possibilità</em> che raccontano.”</blockquote><span>GG STUDIO GIORGI · PRATO</span></div></section>

      <section className="gallery-section section-space" id="spazi"><div className="site-container"><div className="section-heading-row"><div><p className="eyebrow">DENTRO LO STUDIO</p><h2 className="section-title">I nostri spazi.<br /><em>Il nostro modo di essere.</em></h2></div><p className="section-heading-aside">Uno studio dove professionalità e accoglienza si incontrano. Dai uno sguardo ai luoghi in cui prendono forma le nostre idee.</p></div><div className="gallery-grid">{gallery.map((photo, index) => <figure key={photo.src} className={`gallery-item gallery-item-${index + 1}`}><Image src={photo.src} alt={photo.alt} fill sizes={index === 0 ? "(max-width: 800px) 100vw, 55vw" : "(max-width: 800px) 100vw, 38vw"} /><figcaption><span>0{index + 1} / {photo.label}</span><ArrowUpRight size={17} strokeWidth={1.5} /></figcaption></figure>)}</div></div></section>

      <section className="principles-section section-space"><div className="site-container"><p className="eyebrow">QUELLO IN CUI CREDIAMO</p><h2 className="section-title">Un modo di lavorare,<br /><em>un modo di essere.</em></h2><div className="principles-grid"><div><span>01</span><h3>Ascolto</h3><p>Ogni percorso inizia da una domanda e dalla voglia di comprendere davvero ciò di cui hai bisogno.</p></div><div><span>02</span><h3>Chiarezza</h3><p>Rendiamo comprensibili anche le questioni più complesse, per aiutarti a decidere con serenità.</p></div><div><span>03</span><h3>Prospettiva</h3><p>Affrontiamo le sfide di oggi senza perdere di vista le possibilità di domani.</p></div></div></div></section>

      <section className="inline-cta"><div className="site-container inline-cta-inner"><div><span>INCONTRIAMOCI</span><h2>Le storie migliori iniziano <em>di persona.</em></h2></div><Link href="/contatti" className="button button-white">Vieni a trovarci <ArrowUpRight size={18} /></Link></div></section>
    </main>
  );
}
