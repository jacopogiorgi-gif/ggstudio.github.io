import type { Metadata } from "next";
import Link from "next/link";
import { ArrowUpRight, MoveUpRight } from "lucide-react";
import { ServiceIcon } from "@/components/service-icon";
import { services } from "@/lib/site";

export const metadata: Metadata = {
  title: "Competenze",
  description: "Consulenza fiscale, contabile, societaria, aziendale e finanziaria: scopri le competenze di GG Studio Giorgi a Prato.",
};

export default function CompetenzePage() {
  return (
    <main>
      <section className="page-intro page-intro-dark"><div className="site-container page-intro-inner"><p className="eyebrow eyebrow-light">QUELLO CHE FACCIAMO</p><h1>Le competenze giuste.<br /><em>La visione d’insieme.</em></h1><p>Ogni sfida merita una prospettiva completa. Mettiamo in dialogo esperienze e competenze per offrirti un supporto costruito intorno a te.</p><div className="page-intro-index">GG / 02 <span>SCOPRI LE NOSTRE AREE DI ATTIVITÀ</span></div></div><span className="page-intro-decoration" aria-hidden="true">G</span></section>

      <section className="competences-list section-space"><div className="site-container"><div className="section-heading-row"><div><p className="eyebrow">LE NOSTRE AREE DI ATTIVITÀ</p><h2 className="section-title">Al tuo fianco,<br /><em>in ogni scelta.</em></h2></div><p className="section-heading-aside">Dalle attività di ogni giorno ai momenti che cambiano il futuro della tua impresa.</p></div><div className="competence-rows">{services.map((service) => <article id={`servizio-${service.number}`} key={service.number} className="competence-row"><div className="competence-row-number">{service.number}<span> / 06</span></div><div className="competence-row-title"><span className="competence-row-icon"><ServiceIcon name={service.icon} size={29} /></span><h3>{service.title}</h3></div><div className="competence-row-description"><p>{service.description}</p><Link href="/contatti" aria-label={`Chiedi informazioni su ${service.title}`}><MoveUpRight size={21} strokeWidth={1.5} /></Link></div></article>)}</div></div></section>

      <section className="method-section section-space"><div className="site-container method-grid"><div><p className="eyebrow">IL NOSTRO METODO</p><h2 className="section-title">Nessuna formula standard.<br /><em>Solo quella giusta per te.</em></h2></div><div className="method-steps"><div><span>01</span><div><h3>Ci ascoltiamo</h3><p>Partiamo dai tuoi obiettivi e dalle domande che contano davvero.</p></div></div><div><span>02</span><div><h3>Mettiamo a fuoco</h3><p>Analizziamo il quadro completo e individuiamo le opportunità.</p></div></div><div><span>03</span><div><h3>Andiamo avanti, insieme</h3><p>Costruiamo un percorso concreto e lo seguiamo passo dopo passo.</p></div></div></div></div></section>
      <section className="inline-cta"><div className="site-container inline-cta-inner"><div><span>IL TUO PROGETTO, LA NOSTRA ATTENZIONE</span><h2>Parliamo di <em>quello che conta.</em></h2></div><Link href="/contatti" className="button button-white">Contatta lo studio <ArrowUpRight size={18} /></Link></div></section>
    </main>
  );
}
