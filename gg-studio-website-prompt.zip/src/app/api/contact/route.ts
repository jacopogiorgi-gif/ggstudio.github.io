import { db } from "@/db";
import { contactMessages } from "@/db/schema";

export const runtime = "nodejs";

export async function POST(request: Request) {
  const length = Number(request.headers.get("content-length") || 0);
  if (length > 16000) return Response.json({ error: "Messaggio troppo lungo." }, { status: 413 });

  let data: Record<string, unknown>;
  try {
    data = await request.json();
    if (!data || typeof data !== "object" || Array.isArray(data)) throw new Error("Invalid body");
  } catch {
    return Response.json({ error: "Richiesta non valida." }, { status: 400 });
  }

  // Campo invisibile ai visitatori: i bot ricevono una risposta innocua.
  if (data.website) return Response.json({ ok: true });

  const name = typeof data.name === "string" ? data.name.trim() : "";
  const email = typeof data.email === "string" ? data.email.trim().toLowerCase() : "";
  const phone = typeof data.phone === "string" ? data.phone.trim() : "";
  const subject = typeof data.subject === "string" ? data.subject.trim() : "";
  const message = typeof data.message === "string" ? data.message.trim() : "";

  if (name.length < 2 || name.length > 160 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254 || phone.length > 40 || subject.length < 2 || subject.length > 120 || message.length < 10 || message.length > 4000 || data.privacyAccepted !== true) {
    return Response.json({ error: "Controlla i campi del modulo e riprova." }, { status: 400 });
  }

  try {
    await db.insert(contactMessages).values({ name, email, phone: phone || null, subject, message, privacyAccepted: true });
  } catch (error) {
    console.error("Unable to save contact message", error);
    return Response.json({ error: "Non siamo riusciti a ricevere il messaggio. Riprova più tardi." }, { status: 500 });
  }

  // La richiesta è sempre salvata nel pannello admin. La notifica email è
  // facoltativa: attivarla con RESEND_API_KEY e RESEND_FROM_EMAIL verificata.
  if (process.env.RESEND_API_KEY && process.env.RESEND_FROM_EMAIL) {
    try {
      const response = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: { Authorization: `Bearer ${process.env.RESEND_API_KEY}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          from: process.env.RESEND_FROM_EMAIL,
          to: ["info@ggstudio.tax"],
          subject: `Nuovo messaggio dal sito: ${subject.replace(/[\r\n]/g, " ")}`,
          text: `Nome: ${name}\nEmail: ${email}\nTelefono: ${phone || "Non indicato"}\nArgomento: ${subject}\n\n${message}`,
        }),
      });
      if (!response.ok) console.error("Email notification failed", response.status, await response.text());
    } catch (error) {
      console.error("Email notification failed", error);
    }
  }

  return Response.json({ ok: true }, { status: 201 });
}
