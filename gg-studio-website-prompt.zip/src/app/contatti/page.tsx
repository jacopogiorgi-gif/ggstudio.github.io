import type { Metadata } from "next";
import Link from "next/link";
import { ArrowUpRight, Clock3, Mail, MapPin, Phone } from "lucide-react";
import { ContactForm } from "@/components/contact-form";
import { SocialLinks } from "@/components/social-links";
import { openingHours, site } from "@/lib/site";

export const metadata: Metadata = {
  title: "Contatti",
  description: "Contatta GG Studio Giorgi: Via Giuseppe Verdi 18, 59100 Prato. Telefono 0574 572757, email info@ggstudio.tax. Scopri orari e indicazioni.",
};

export default function ContattiPage() {
  return (
    <main>
      <section className="contact-page-hero"><div className="site-container contact-page-hero-inner"><div><p className="eyebrow">CONTATTI <span className="eyebrow-dot">·</span> GG STUDIO GIORGI</p><h1>Iniziamo da una<br /><em>conversazione.</em></h1><p>Hai una domanda, un progetto o semplicemente voglia di conoscerci? Siamo qui per ascoltarti.</p></div><span className="contact-hero-index">GG / 04<br /><small>PARLIAMONE</small></span></div></section>
      <section className="contact-content-section"><div className="site-container contact-content-grid"><ContactForm /><aside className="contact-sidebar"><div className="sidebar-top"><span className="sidebar-kicker">02 / TROVACI QUI</span><h2>Le porte dello studio <em>sono aperte.</em></h2><p>Vieni a trovarci nel cuore di Prato o scegli il modo più comodo per metterti in contatto con noi.</p></div><div className="contact-detail"><span className="contact-detail-icon"><MapPin size={19} strokeWidth={1.5} /></span><div><span>INDIRIZZO</span><a href={site.mapsLink} target="_blank" rel="noopener noreferrer">Via Giuseppe Verdi n. 18<br />59100 Prato (PO) <ArrowUpRight size={15} /></a></div></div><div className="contact-detail"><span className="contact-detail-icon"><Phone size={19} strokeWidth={1.5} /></span><div><span>TELEFONO</span><a href={site.phoneHref}>{site.phone} <ArrowUpRight size={15} /></a></div></div><div className="contact-detail"><span className="contact-detail-icon"><Mail size={19} strokeWidth={1.5} /></span><div><span>EMAIL</span><a href={site.emailHref}>{site.email} <ArrowUpRight size={15} /></a></div></div><div className="sidebar-social"><span>SEGUICI SUI SOCIAL</span><SocialLinks /></div></aside></div></section>
      <section className="hours-map-section section-space"><div className="site-container"><div className="hours-map-heading"><div><p className="eyebrow">VIENI A TROVARCI</p><h2 className="section-title">Ci trovi <em>a Prato.</em></h2></div><p>Un luogo di incontro, confronto e nuove prospettive. Ti aspettiamo in Via Giuseppe Verdi 18.</p></div><div className="hours-map-grid"><div className="map-box"><iframe title="Mappa Google Maps: GG Studio Giorgi, Via Giuseppe Verdi 18, Prato" src={site.mapsEmbed} loading="lazy" referrerPolicy="no-referrer-when-downgrade" allowFullScreen /><a href={site.mapsLink} target="_blank" rel="noopener noreferrer" className="map-directions">Apri in Google Maps <ArrowUpRight size={17} /></a></div><div className="hours-card"><span className="hours-card-icon"><Clock3 size={24} strokeWidth={1.5} /></span><h3>Orari di apertura</h3><p>Passa a trovarci durante i nostri orari.</p><div className="hours-list">{openingHours.map((item) => <div key={item.day}><span>{item.day}</span><span>{item.hours}</span></div>)}</div><div className="hours-card-footer">Per un appuntamento, <Link href={site.emailHref}>scrivici <ArrowUpRight size={15} /></Link></div></div></div></div></section>
    </main>
  );
}
