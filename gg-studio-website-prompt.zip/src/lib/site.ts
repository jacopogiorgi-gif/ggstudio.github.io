export const site = {
  name: "GG Studio Giorgi",
  claim: "Professionisti per l’impresa",
  address: "Via Giuseppe Verdi n. 18, 59100 Prato",
  shortAddress: "Via Giuseppe Verdi 18, Prato",
  phone: "0574 572757",
  phoneHref: "tel:+390574572757",
  email: "info@ggstudio.tax",
  emailHref: "mailto:info@ggstudio.tax",
  website: "https://ggstudio.tax",
  mapsLink:
    "https://www.google.com/maps/search/?api=1&query=Via+Giuseppe+Verdi+18%2C+59100+Prato",
  mapsEmbed:
    "https://maps.google.com/maps?q=Via%20Giuseppe%20Verdi%2018%2C%2059100%20Prato%2C%20Italia&z=16&output=embed",
};

export const navigation = [
  { label: "Home", href: "/" },
  { label: "Lo studio", href: "/studio" },
  { label: "Competenze", href: "/competenze" },
  { label: "News", href: "/news" },
  { label: "Contatti", href: "/contatti" },
];

// Profili ufficiali indicati direttamente dallo Studio.
export const socialLinks = [
  {
    name: "Facebook",
    href: "https://www.facebook.com/studiogiorgi.giorgi/",
    label: "GG Studio Giorgi su Facebook",
  },
  {
    name: "Instagram",
    href: "https://www.instagram.com/ggstudiogiorgi/",
    label: "GG Studio Giorgi su Instagram",
  },
  {
    name: "YouTube",
    href: "https://www.youtube.com/@ggstudiogiorgi",
    label: "GG Studio Giorgi su YouTube",
  },
  {
    name: "TikTok",
    href: "https://www.tiktok.com/@ggstudiogiorgi",
    label: "GG Studio Giorgi su TikTok",
  },
] as const;

export const openingHours = [
  { day: "Lunedì", hours: "09:00–13:00 · 15:00–19:00" },
  { day: "Martedì", hours: "09:00–13:00" },
  { day: "Mercoledì", hours: "09:00–13:00 · 15:00–19:00" },
  { day: "Giovedì", hours: "09:00–13:00" },
  { day: "Venerdì", hours: "09:00–13:00 · 15:00–19:00" },
  { day: "Sabato e domenica", hours: "Chiuso" },
];

export const services = [
  {
    number: "01",
    icon: "chart",
    title: "Consulenza fiscale e tributaria",
    short: "Decisioni consapevoli in un panorama normativo in continua evoluzione.",
    description:
      "Affianchiamo imprese, professionisti e persone nella gestione degli adempimenti fiscali e nella lettura delle opportunità, con un approccio attento alle esigenze di ciascuno.",
  },
  {
    number: "02",
    icon: "calculator",
    title: "Consulenza contabile",
    short: "Numeri chiari per costruire scelte solide e guardare avanti.",
    description:
      "Dalla tenuta della contabilità alla lettura dei dati economici: trasformiamo le informazioni in strumenti utili per orientare l’attività quotidiana.",
  },
  {
    number: "03",
    icon: "building",
    title: "Consulenza societaria",
    short: "La struttura giusta per ogni fase della vita d’impresa.",
    description:
      "Supportiamo le imprese nelle scelte societarie, nei passaggi di crescita e nell’organizzazione delle attività, mettendo al centro obiettivi e prospettive.",
  },
  {
    number: "04",
    icon: "compass",
    title: "Consulenza aziendale e finanziaria",
    short: "Una visione d’insieme per dare direzione ai tuoi progetti.",
    description:
      "Analizziamo scenari, esigenze e possibilità per accompagnare imprenditori e professionisti nelle decisioni strategiche e finanziarie.",
  },
  {
    number: "05",
    icon: "arrows",
    title: "Operazioni straordinarie",
    short: "Competenza e metodo nei momenti di cambiamento.",
    description:
      "Quando l’impresa evolve, serve uno sguardo completo. Offriamo supporto nella valutazione e nella gestione delle operazioni straordinarie.",
  },
  {
    number: "06",
    icon: "shield",
    title: "Tutela del patrimonio",
    short: "Proteggere ciò che hai costruito, con uno sguardo al futuro.",
    description:
      "Lavoriamo al fianco dei clienti per individuare strumenti e percorsi coerenti con la protezione del patrimonio e la continuità dei progetti.",
  },
] as const;

export const gallery = [
  {
    src: "/images/studio-archivio-2.jpg",
    alt: "Zona accoglienza e corridoio all’interno di GG Studio Giorgi",
    label: "Gli spazi dello Studio",
  },
  {
    src: "/images/studio-07.jpg",
    alt: "Dettaglio delle opere d’arte negli uffici dello Studio",
    label: "Arte e dettagli",
  },
  {
    src: "/images/studio-04.jpg",
    alt: "Libreria e volumi all’interno di GG Studio Giorgi",
    label: "I nostri dettagli",
  },
  {
    src: "/images/studio-archivio.jpg",
    alt: "Insegna GG Studio Giorgi all’ingresso dello Studio",
    label: "GG Studio Giorgi",
  },
] as const;

export function formatItalianDate(date: Date | string) {
  return new Intl.DateTimeFormat("it-IT", {
    day: "numeric",
    month: "long",
    year: "numeric",
  }).format(new Date(date));
}
