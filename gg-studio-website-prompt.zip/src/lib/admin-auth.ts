import { createHash, createHmac, timingSafeEqual } from "node:crypto";
import { cookies } from "next/headers";

export const ADMIN_COOKIE = "ggstudio_admin_session";
const SESSION_SECONDS = 60 * 60 * 8;

function secret() {
  return process.env.NEWS_ADMIN_PASSWORD;
}

export function adminConfigured() {
  return Boolean(secret() && secret()!.length >= 12);
}

export function verifyPassword(candidate: string) {
  const expected = secret();
  if (!expected || expected.length < 12) return false;
  const candidateHash = createHash("sha256").update(candidate).digest();
  const expectedHash = createHash("sha256").update(expected).digest();
  return timingSafeEqual(candidateHash, expectedHash);
}

function sign(expires: string) {
  return createHmac("sha256", secret() ?? "unconfigured")
    .update(`ggstudio-admin:${expires}`)
    .digest("hex");
}

export function createAdminSession() {
  const expires = String(Date.now() + SESSION_SECONDS * 1000);
  return `${expires}.${sign(expires)}`;
}

export async function isAdmin() {
  if (!adminConfigured()) return false;
  const cookieStore = await cookies();
  const value = cookieStore.get(ADMIN_COOKIE)?.value;
  if (!value) return false;
  const [expires, signature, extra] = value.split(".");
  if (extra || !expires || !signature || !/^\d{13}$/.test(expires)) return false;
  if (Number(expires) < Date.now() || !/^[a-f0-9]{64}$/.test(signature)) return false;
  const actual = Buffer.from(signature, "hex");
  const expected = Buffer.from(sign(expires), "hex");
  return timingSafeEqual(actual, expected);
}

export const adminCookieOptions = {
  httpOnly: true,
  sameSite: "lax" as const,
  secure: process.env.NODE_ENV === "production" && process.env.NEXT_PUBLIC_SITE_URL !== "http://localhost:3000",
  path: "/",
  maxAge: SESSION_SECONDS,
};
